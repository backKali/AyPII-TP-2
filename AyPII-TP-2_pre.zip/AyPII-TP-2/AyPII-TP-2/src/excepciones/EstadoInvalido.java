package excepciones;

public class EstadoInvalido extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -878665292545156144L;
	
	public EstadoInvalido(String mensaje){
		super(mensaje);
	}
	

}