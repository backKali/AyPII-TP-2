package excepciones;

public class NumeroInvalido extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -163995313794786489L;
	
	public NumeroInvalido(String mensaje){
		super(mensaje);
	}
	
	

}