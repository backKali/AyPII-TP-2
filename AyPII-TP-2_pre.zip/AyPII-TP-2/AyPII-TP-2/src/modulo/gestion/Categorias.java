package modulo.gestion;

public enum Categorias {

	BEBIDAS_SIN_ALCOHOL, 
	BEBIDAS_CON_ALCOHOL,
	HAMBURGUESAS, 
	PIZZAS,
	MINUTAS, 
	OTROS, 
	COMBOS;

}
