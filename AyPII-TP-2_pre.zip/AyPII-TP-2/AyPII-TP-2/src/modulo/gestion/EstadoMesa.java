package modulo.gestion;

public enum EstadoMesa {	
	
	DISPONIBLE,
	CERRADA,
	OCUPADA

}
